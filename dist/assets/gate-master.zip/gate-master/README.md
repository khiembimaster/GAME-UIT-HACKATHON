# gate
open source game made in phaser 3, html5 and typescript.
Complimented by a [video tutorial series](https://www.youtube.com/watch?v=OS7neDUUhPE)

# goals
* cutscenes and dialouge system for story
* touch on as many phaser3 features as possible
* super easy way to contribute levels with tiled
* multiplayer???
